# Carculator
Jednoduchá Next.js aplikácia na výber auta podľa preferencií.
