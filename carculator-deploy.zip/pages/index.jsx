import Head from 'next/head';
import CarculatorWizard from '../components/CarculatorWizard';

export default function Home() {
  const handleComplete = (formData) => {
    console.log('Zadane vstupy:', formData);
  };

  return (
    <>
      <Head>
        <title>Carculator</title>
        <meta name="description" content="Vyber auta pomocou Carculator" />
      </Head>
      <main className="min-h-screen bg-white">
        <h1 className="text-center text-3xl font-bold my-6 text-brand-blue">
          Carculator
        </h1>
        <CarculatorWizard onComplete={handleComplete} />
      </main>
    </>
  );
}
