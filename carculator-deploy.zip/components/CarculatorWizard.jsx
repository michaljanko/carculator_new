
// Tu bude vložený celý obsah CarculatorWizard.jsx (získaný predtým z platne)
// Kvôli veľkosti a prehľadnosti to bude vložené v nasledujúcom kroku samostatne
